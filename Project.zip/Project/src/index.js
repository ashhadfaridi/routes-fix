import React from 'react';
import ReactDOM from 'react-dom';
import "./style.css"
import App from './App';
import stores from './stores/index'
import {Provider} from 'react-redux'
import Login from './login'
ReactDOM.render(
    <React.StrictMode>
        <Provider store={stores}>
            <App/>
        </Provider>
    </React.StrictMode>,
    document.getElementById('root')
);
