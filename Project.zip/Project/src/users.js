const users = [
    {
        email : "crhalby@gmail.com",
        username : "crhalby",
        password : "password"
    },
    {
        email:"lalita@iastate.edu",
        username : "lali",
        password : "password"
    }
]

export default users;