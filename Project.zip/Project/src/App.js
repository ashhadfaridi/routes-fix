import { BrowserRouter as Router, Switch, Route, Redirect } from "react-router-dom"
import Sidebar from './components/Sidebar'
import Content from "./components/Content";
import Login from './login'
function App() {
  return (

    <Router>
      <div className="wrapper">
        <Sidebar />
        <Content />
      </div>
      {/* <BottomBar /> */}
    </Router>
    // <Sidebar/>
    // <div className="wrapper">
    // <Router>
    //   {/* <Sidebar /> */} 
    //   <Switch>
    //     <Route exact  path="/"><Redirect to={{pathname:'/login'}}/></Route> 
    //     <Route path="/sidebar">
    //       {/* <Sidebar/> */}
    //       <Content/>
    //     </Route> 
    //     <Route exact path="/login"><Login/></Route>

    //    </Switch>
    //   {/* <Content /> */}
    // </Router>
    // </div>



  );
}

export default App;
